CREATE DATABASE `pfr`;

USE `pfr`;

CREATE TABLE `pfr`.`client` (
  `codeC` VARCHAR(4) NOT NULL,
  `nom` VARCHAR(20) NOT NULL,
  `prenom` VARCHAR(20) NULL,
  `adresse` VARCHAR(50) NULL,
  `telephone` VARCHAR(20) NULL,
  `email` VARCHAR(50) NULL,
  PRIMARY KEY (`codeC`) );

CREATE TABLE `pfr`.`sejour` (
  `id` VARCHAR(4) NOT NULL,
  `theme` VARCHAR(2) NOT NULL,
  `date` INT(2) NOT NULL,
  `annee` INT(4) NOT NULL,
    PRIMARY KEY (`id`) );

CREATE TABLE `pfr`.`controleur` (
  `id` VARCHAR(4) NOT NULL,
  `nom` VARCHAR(20) NOT NULL,
  `prenom` VARCHAR(20) NOT NULL,
  PRIMARY KEY (`id`) );

CREATE TABLE `pfr`.`parking` (
  `id` VARCHAR(4) NOT NULL,
  `nom` VARCHAR(20) NOT NULL,
  `adresse` VARCHAR(50) NOT NULL,
  `code_postal` VARCHAR(5) NOT NULL,
  `ville` VARCHAR(40) NOT NULL,
  PRIMARY KEY (`id`) );

  CREATE TABLE `pfr`.`voiture` (
    `immat` VARCHAR(10) NOT NULL,
    `marque` VARCHAR(20) NOT NULL,
    `modele` VARCHAR(20) NOT NULL,
    `id_controleur` VARCHAR(4) NOT NULL,
    `categorie` VARCHAR(20) NOT NULL,
    `places` INT NOT NULL CHECK (places <= 4),
    `disponibilite` BOOLEAN NOT NULL,
    `motif_indisponibilite` VARCHAR(120) NULL,
    `id_parking` VARCHAR(4) NOT NULL,
    `place_parking` VARCHAR(2) NOT NULL,
    PRIMARY KEY (`immat`),
     CONSTRAINT `id_controleur_voiture` FOREIGN KEY (`id_controleur`)
  		REFERENCES `pfr`.`controleur` (`id`)
  		ON DELETE NO ACTION
  		ON UPDATE NO ACTION );

CREATE TABLE `pfr`.`intervention` (
  `id` VARCHAR(4) NOT NULL,
  `immat` VARCHAR(10) NOT NULL,
  `id_controleur` VARCHAR(4) NOT NULL,
  `type_intervention` VARCHAR(20) NOT NULL,
  `date` DATE NOT NULL,
  PRIMARY KEY (`id`),
   CONSTRAINT `immat_voiture_intervention` FOREIGN KEY (`immat`)
    REFERENCES `pfr`.`voiture` (`immat`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
   CONSTRAINT `id_controleur_intervention` FOREIGN KEY (`id_controleur`)
 	  REFERENCES `pfr`.`controleur` (`id`)
 		 ON DELETE NO ACTION
 		 ON UPDATE NO ACTION );

CREATE TABLE `pfr`.`location` (
  `id` VARCHAR(4) NOT NULL,
  `sejour` VARCHAR(3) NOT NULL,
  `immat` VARCHAR(10) NOT NULL,
  `codeC` VARCHAR(4) NOT NULL,
  `appreciation` VARCHAR(120) NULL,
  `note` INT NULL CHECK (note <= 5),
  PRIMARY KEY (`id`, `sejour`, `immat`, `codeC`),
   INDEX `F_loc1_idx` (`id` ASC),
   INDEX `F_loc2_idx` (`sejour` ASC),
   INDEX `F_loc3_idx` (`immat` ASC),
   INDEX `F_loc4_idx` (`codeC` ASC),
   CONSTRAINT `sejour_location` FOREIGN KEY (`sejour`)
		REFERENCES `pfr`.`sejour` (`id`)
		ON DELETE NO ACTION
		ON UPDATE NO ACTION,
  CONSTRAINT `immat_location` FOREIGN KEY (`immat`)
		REFERENCES `pfr`.`voiture` (`immat`)
		ON DELETE NO ACTION
		ON UPDATE NO ACTION,
  CONSTRAINT `codeC_location` FOREIGN KEY (`codeC`)
    REFERENCES `pfr`.`client` (`codeC`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION  );
