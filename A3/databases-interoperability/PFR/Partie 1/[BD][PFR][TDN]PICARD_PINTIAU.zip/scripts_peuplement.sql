/* ========== INSERTION DANS LA TABLE PARKING ========== */

INSERT INTO `pfr`.`parking` (`id`, `nom`, `adresse`, `code_postal`, `ville`) VALUES ('P1', 'Rivoli', '2 Rue Boucher', '75001', 'Paris');
INSERT INTO `pfr`.`parking` (`id`, `nom`, `adresse`, `code_postal`, `ville`) VALUES ('P2', 'Rivoli', '2 Rue Boucher', '75002', 'Paris');
INSERT INTO `pfr`.`parking` (`id`, `nom`, `adresse`, `code_postal`, `ville`) VALUES ('P3', 'Beaubourg', '31 Rue Beaubourg', '75003', 'Paris');
INSERT INTO `pfr`.`parking` (`id`, `nom`, `adresse`, `code_postal`, `ville`) VALUES ('P4', 'Lobau', '4 Rue Lobau', '75004', 'Paris');
INSERT INTO `pfr`.`parking` (`id`, `nom`, `adresse`, `code_postal`, `ville`) VALUES ('P5', 'Soufflot', '22 Rue Soufflot', '75005', 'Paris');
INSERT INTO `pfr`.`parking` (`id`, `nom`, `adresse`, `code_postal`, `ville`) VALUES ('P6', 'Jardin des Plantes', '25 Rue Geoffroy-Saint-Hilaire', '75006', 'Paris');
INSERT INTO `pfr`.`parking` (`id`, `nom`, `adresse`, `code_postal`, `ville`) VALUES ('P7', 'Maubourg', '45 Quai d''Orsay', '75007', 'Paris');
INSERT INTO `pfr`.`parking` (`id`, `nom`, `adresse`, `code_postal`, `ville`) VALUES ('P8', 'Champs-Elysées', '77 Avenue Marceau', '75008', 'Paris');
INSERT INTO `pfr`.`parking` (`id`, `nom`, `adresse`, `code_postal`, `ville`) VALUES ('P9', 'Pigalle', '10 Rue Jean-Baptiste Pigalle', '75009', 'Paris');
INSERT INTO `pfr`.`parking` (`id`, `nom`, `adresse`, `code_postal`, `ville`) VALUES ('P10', 'Lariboisière', '1 bis Rue Ambroise Paré', '75010', 'Paris');
INSERT INTO `pfr`.`parking` (`id`, `nom`, `adresse`, `code_postal`, `ville`) VALUES ('P11', 'Oberkampf', '11 Rue Ternaux', '75011', 'Paris');
INSERT INTO `pfr`.`parking` (`id`, `nom`, `adresse`, `code_postal`, `ville`) VALUES ('P12', 'Gare de Lyon', '6 Rue de Rambouillet', '75012', 'Paris');
INSERT INTO `pfr`.`parking` (`id`, `nom`, `adresse`, `code_postal`, `ville`) VALUES ('P13', 'Italie', '25 Rue Stephen Pichon', '75013', 'Paris');
INSERT INTO `pfr`.`parking` (`id`, `nom`, `adresse`, `code_postal`, `ville`) VALUES ('P14', 'Raspail', '120 Boulevard du Montparnasse', '75014', 'Paris');
INSERT INTO `pfr`.`parking` (`id`, `nom`, `adresse`, `code_postal`, `ville`) VALUES ('P15', 'Beaugrenelle', '5 Quai Andre Citroen', '75015', 'Paris');
INSERT INTO `pfr`.`parking` (`id`, `nom`, `adresse`, `code_postal`, `ville`) VALUES ('P16', 'Victor Hugo', '74 Avenue Victor Hugo', '75016', 'Paris');
INSERT INTO `pfr`.`parking` (`id`, `nom`, `adresse`, `code_postal`, `ville`) VALUES ('P17', 'Ternes', '38 Avenue des Ternes', '75017', 'Paris');
INSERT INTO `pfr`.`parking` (`id`, `nom`, `adresse`, `code_postal`, `ville`) VALUES ('P18', 'Stalingrad', '13 Rue d''Aubervilliers', '75018', 'Paris');
INSERT INTO `pfr`.`parking` (`id`, `nom`, `adresse`, `code_postal`, `ville`) VALUES ('P19', 'Philharmonie', '185 Boulevard Sérurier', '75019', 'Paris');
INSERT INTO `pfr`.`parking` (`id`, `nom`, `adresse`, `code_postal`, `ville`) VALUES ('P20', 'Rosa Parks', '157 Boulevard Macdonald', '75020', 'Paris');
INSERT INTO `pfr`.`parking` (`id`, `nom`, `adresse`, `code_postal`, `ville`) VALUES ('P21', 'Orly', 'Orly Airport', '94310', 'Orly');
INSERT INTO `pfr`.`parking` (`id`, `nom`, `adresse`, `code_postal`, `ville`) VALUES ('P22', 'Roissy', 'Roissy Airport', '95700', 'Roissy en France');

/* ========== INSERTION DANS LA TABLE CONTROLEUR ========== */

INSERT INTO `pfr`.`controleur` (`id`, `nom`, `prenom`) VALUES ('CL1', 'Doiron', 'Rémy');
INSERT INTO `pfr`.`controleur` (`id`, `nom`, `prenom`) VALUES ('CL2', 'Simard', 'Benjamin');
INSERT INTO `pfr`.`controleur` (`id`, `nom`, `prenom`) VALUES ('CL3', 'Leroux', 'Thierry');

/* ========== INSERTION DANS LA TABLE CLIENT ========== */

INSERT INTO `pfr`.`client` (`codeC`, `nom`, `prenom`, `adresse`, `telephone`, `email`) VALUES ('C1', 'Lagueux', 'Isabelle', '87 Rue Hubert de Lisle 33310 LORMONT', '0524849895', 'isabellelagueux@wanadoo.fr');
INSERT INTO `pfr`.`client` (`codeC`, `nom`, `prenom`, `adresse`, `telephone`, `email`) VALUES ('C2', 'Saindon', 'Anton', '29 Avenue de l''Amandier 92270 BOIS-COLOMBES', '0112788512', 'antonsaindon@hotmail.fr');
INSERT INTO `pfr`.`client` (`codeC`, `nom`, `prenom`, `adresse`, `telephone`, `email`) VALUES ('C3', 'Martinez', 'Robert E.', '794 Willow Greene Drive Andalusia AL 36420', '334-222-0744', 'robertemartinez@gmail.com');
INSERT INTO `pfr`.`client` (`codeC`, `nom`, `prenom`, `adresse`, `telephone`, `email`) VALUES ('C4', 'Metzger', 'Lukas ', 'Borstelmannsweg 7 92239 Hirschau', '09608538975', 'lukasmetzger@yahoo.de');
INSERT INTO `pfr`.`client` (`codeC`, `nom`, `prenom`, `adresse`, `telephone`, `email`) VALUES ('C5', 'Whitehouse', 'Adam', '12 Harrogate Road RUSHWICK WR26TX', '07038185146', 'adamwhitehouse@gmail.com');
INSERT INTO `pfr`.`client` (`codeC`, `nom`, `prenom`, `adresse`, `telephone`, `email`) VALUES ('C6', 'Pavlicek', 'Lukas ', 'Alsova 1350 582 22 Pribyslav', '566253204', 'lukaspavlicek@gmail.com');

/* ========== INSERTION DANS LA TABLE SEJOUR ========== */

INSERT INTO `pfr`.`sejour` (`id`, `theme`, `date`, `annee`) VALUES ('S1', '04', '21', 2018);
INSERT INTO `pfr`.`sejour` (`id`, `theme`, `date`, `annee`) VALUES ('S2', '11', '38', 2018);
INSERT INTO `pfr`.`sejour` (`id`, `theme`, `date`, `annee`) VALUES ('S3', '16', '46', 2018);
INSERT INTO `pfr`.`sejour` (`id`, `theme`, `date`, `annee`) VALUES ('S4', '18', '51', 2018);

/* ========== INSERTION DANS LA TABLE VOITURE ========== */
/* CABRIOLETS 2 PLACES */
INSERT INTO `pfr`.`voiture` (`immat`, `marque`, `modele`, `id_controleur`, `categorie`, `places`, `disponibilite`, `motif_indisponibilite`, `id_parking`, `place_parking`) VALUES ('405DFG75', 'Audi', 'TT', 'CL1', 'cabriolet', '2', true, null, 'P1', 'A0');
INSERT INTO `pfr`.`voiture` (`immat`, `marque`, `modele`, `id_controleur`, `categorie`, `places`, `disponibilite`, `motif_indisponibilite`, `id_parking`, `place_parking`) VALUES ('222HUY75', 'BMW', 'Z4', 'CL1', 'cabriolet', '2', true, null, 'P2', 'A0');
INSERT INTO `pfr`.`voiture` (`immat`, `marque`, `modele`, `id_controleur`, `categorie`, `places`, `disponibilite`, `motif_indisponibilite`, `id_parking`, `place_parking`) VALUES ('261MDU75', 'Chrysler', 'Crossfire', 'CL1', 'cabriolet', '2', true, null, 'P3', 'A0');
INSERT INTO `pfr`.`voiture` (`immat`, `marque`, `modele`, `id_controleur`, `categorie`, `places`, `disponibilite`, `motif_indisponibilite`, `id_parking`, `place_parking`) VALUES ('420FDH75', 'Corvette', 'C6', 'CL1', 'cabriolet', '2', true, null, 'P4', 'A0');
INSERT INTO `pfr`.`voiture` (`immat`, `marque`, `modele`, `id_controleur`, `categorie`, `places`, `disponibilite`, `motif_indisponibilite`, `id_parking`, `place_parking`) VALUES ('317KDU75', 'Ferrari', 'F430 Spider', 'CL1', 'cabriolet', '2', true, null, 'P5', 'A0');
INSERT INTO `pfr`.`voiture` (`immat`, `marque`, `modele`, `id_controleur`, `categorie`, `places`, `disponibilite`, `motif_indisponibilite`, `id_parking`, `place_parking`) VALUES ('248QCH75', 'Fiat', 'Barchetta', 'CL1', 'cabriolet', '2', true, null, 'P6', 'A0');
INSERT INTO `pfr`.`voiture` (`immat`, `marque`, `modele`, `id_controleur`, `categorie`, `places`, `disponibilite`, `motif_indisponibilite`, `id_parking`, `place_parking`) VALUES ('409MBU75', 'Ford', 'Streetka', 'CL1', 'cabriolet', '2', true, null, 'P7', 'A0');
INSERT INTO `pfr`.`voiture` (`immat`, `marque`, `modele`, `id_controleur`, `categorie`, `places`, `disponibilite`, `motif_indisponibilite`, `id_parking`, `place_parking`) VALUES ('468NBV75', 'Honda', 'S2000', 'CL1', 'cabriolet', '2', true, null, 'P8', 'A0');
INSERT INTO `pfr`.`voiture` (`immat`, `marque`, `modele`, `id_controleur`, `categorie`, `places`, `disponibilite`, `motif_indisponibilite`, `id_parking`, `place_parking`) VALUES ('494MQT75', 'Lotus', 'Elise', 'CL1', 'cabriolet', '2', true, null, 'P9', 'A0');
INSERT INTO `pfr`.`voiture` (`immat`, `marque`, `modele`, `id_controleur`, `categorie`, `places`, `disponibilite`, `motif_indisponibilite`, `id_parking`, `place_parking`) VALUES ('114ACO75', 'Maserati', 'Spider', 'CL1', 'cabriolet', '2', true, null, 'P10', 'A0');
INSERT INTO `pfr`.`voiture` (`immat`, `marque`, `modele`, `id_controleur`, `categorie`, `places`, `disponibilite`, `motif_indisponibilite`, `id_parking`, `place_parking`) VALUES ('223JDI75', 'Mazda', 'MX5', 'CL1', 'cabriolet', '2', true, null, 'P11', 'A0');
INSERT INTO `pfr`.`voiture` (`immat`, `marque`, `modele`, `id_controleur`, `categorie`, `places`, `disponibilite`, `motif_indisponibilite`, `id_parking`, `place_parking`) VALUES ('484API75', 'MG', 'TF', 'CL1', 'cabriolet', '2', true, null, 'P12', 'A0');
INSERT INTO `pfr`.`voiture` (`immat`, `marque`, `modele`, `id_controleur`, `categorie`, `places`, `disponibilite`, `motif_indisponibilite`, `id_parking`, `place_parking`) VALUES ('385ZER75', 'Nissan', '350Z', 'CL1', 'cabriolet', '2', true, null, 'P13', 'A0');
INSERT INTO `pfr`.`voiture` (`immat`, `marque`, `modele`, `id_controleur`, `categorie`, `places`, `disponibilite`, `motif_indisponibilite`, `id_parking`, `place_parking`) VALUES ('425YTG75', 'Porsche', 'Boxster', 'CL1', 'cabriolet', '2', true, null, 'P14', 'A0');
INSERT INTO `pfr`.`voiture` (`immat`, `marque`, `modele`, `id_controleur`, `categorie`, `places`, `disponibilite`, `motif_indisponibilite`, `id_parking`, `place_parking`) VALUES ('376OSU75', 'Smart', 'Fortwo Cabrio', 'CL2', 'cabriolet', '2', true, null, 'P15', 'A0');
INSERT INTO `pfr`.`voiture` (`immat`, `marque`, `modele`, `id_controleur`, `categorie`, `places`, `disponibilite`, `motif_indisponibilite`, `id_parking`, `place_parking`) VALUES ('474SRC75', 'Fiat', '500C', 'CL2', 'cabriolet', '2', true, null, 'P16', 'A0');
INSERT INTO `pfr`.`voiture` (`immat`, `marque`, `modele`, `id_controleur`, `categorie`, `places`, `disponibilite`, `motif_indisponibilite`, `id_parking`, `place_parking`) VALUES ('172DJI75', 'Peugeot', '207 CC', 'CL2', 'cabriolet', '2', true, null, 'P21', 'A0');
INSERT INTO `pfr`.`voiture` (`immat`, `marque`, `modele`, `id_controleur`, `categorie`, `places`, `disponibilite`, `motif_indisponibilite`, `id_parking`, `place_parking`) VALUES ('256RYU75', 'Audi', 'A5', 'CL2', 'cabriolet', '2', true, null, 'P21', 'A1');
INSERT INTO `pfr`.`voiture` (`immat`, `marque`, `modele`, `id_controleur`, `categorie`, `places`, `disponibilite`, `motif_indisponibilite`, `id_parking`, `place_parking`) VALUES ('304TZO75', 'Audi', 'A5', 'CL2', 'cabriolet', '2', true, null, 'P22', 'A0');
INSERT INTO `pfr`.`voiture` (`immat`, `marque`, `modele`, `id_controleur`, `categorie`, `places`, `disponibilite`, `motif_indisponibilite`, `id_parking`, `place_parking`) VALUES ('188SIJ75', 'Mercedes', 'Classe E', 'CL2', 'cabriolet', '2', true, null, 'P22', 'A1');

/* BERLINES 4 PLACES */

INSERT INTO `pfr`.`voiture` (`immat`, `marque`, `modele`, `id_controleur`, `categorie`, `places`, `disponibilite`, `motif_indisponibilite`, `id_parking`, `place_parking`) VALUES ('336DJO75', 'Dacia', 'Logan', 'CL2', 'berline', '4', true, null, 'P17', 'A0');
INSERT INTO `pfr`.`voiture` (`immat`, `marque`, `modele`, `id_controleur`, `categorie`, `places`, `disponibilite`, `motif_indisponibilite`, `id_parking`, `place_parking`) VALUES ('197MQS75', 'Dacia', 'Sandero', 'CL2', 'berline', '4', true, null, 'P18', 'A0');
INSERT INTO `pfr`.`voiture` (`immat`, `marque`, `modele`, `id_controleur`, `categorie`, `places`, `disponibilite`, `motif_indisponibilite`, `id_parking`, `place_parking`) VALUES ('341GEJ75', 'Fiat', 'Tipo', 'CL2', 'berline', '4', true, null, 'P19', 'A0');
INSERT INTO `pfr`.`voiture` (`immat`, `marque`, `modele`, `id_controleur`, `categorie`, `places`, `disponibilite`, `motif_indisponibilite`, `id_parking`, `place_parking`) VALUES ('343LSD75', 'Suzuki', 'Baleno', 'CL2', 'berline', '4', true, null, 'P20', 'A0');
INSERT INTO `pfr`.`voiture` (`immat`, `marque`, `modele`, `id_controleur`, `categorie`, `places`, `disponibilite`, `motif_indisponibilite`, `id_parking`, `place_parking`) VALUES ('396EIK75', 'Citroen', 'C4 Cactus', 'CL2', 'berline', '4', true, null, 'P1', 'A1');
INSERT INTO `pfr`.`voiture` (`immat`, `marque`, `modele`, `id_controleur`, `categorie`, `places`, `disponibilite`, `motif_indisponibilite`, `id_parking`, `place_parking`) VALUES ('371EIL75', 'Kia', 'Cee''d', 'CL2', 'berline', '4', true, null, 'P2', 'A1');
INSERT INTO `pfr`.`voiture` (`immat`, `marque`, `modele`, `id_controleur`, `categorie`, `places`, `disponibilite`, `motif_indisponibilite`, `id_parking`, `place_parking`) VALUES ('221EKO75', 'Ford', 'Focus', 'CL2', 'berline', '4', true, null, 'P3', 'A1');
INSERT INTO `pfr`.`voiture` (`immat`, `marque`, `modele`, `id_controleur`, `categorie`, `places`, `disponibilite`, `motif_indisponibilite`, `id_parking`, `place_parking`) VALUES ('109PKZ75', 'Skoda', 'Octavia', 'CL3', 'berline', '4', true, null, 'P4', 'A1');
INSERT INTO `pfr`.`voiture` (`immat`, `marque`, `modele`, `id_controleur`, `categorie`, `places`, `disponibilite`, `motif_indisponibilite`, `id_parking`, `place_parking`) VALUES ('294SIY75', 'Nissan', 'Pulsar', 'CL3', 'berline', '4', true, null, 'P5', 'A1');
INSERT INTO `pfr`.`voiture` (`immat`, `marque`, `modele`, `id_controleur`, `categorie`, `places`, `disponibilite`, `motif_indisponibilite`, `id_parking`, `place_parking`) VALUES ('376DHU75', 'Volkswagen', 'Golf', 'CL3', 'berline', '4', true, null, 'P6', 'A1');
INSERT INTO `pfr`.`voiture` (`immat`, `marque`, `modele`, `id_controleur`, `categorie`, `places`, `disponibilite`, `motif_indisponibilite`, `id_parking`, `place_parking`) VALUES ('398XNI75', 'Renault', 'Megane', 'CL3', 'berline', '4', true, null, 'P7', 'A1');
INSERT INTO `pfr`.`voiture` (`immat`, `marque`, `modele`, `id_controleur`, `categorie`, `places`, `disponibilite`, `motif_indisponibilite`, `id_parking`, `place_parking`) VALUES ('379SID75', 'Toyota', 'Auris', 'CL3', 'berline', '4', true, null, 'P8', 'A1');
INSERT INTO `pfr`.`voiture` (`immat`, `marque`, `modele`, `id_controleur`, `categorie`, `places`, `disponibilite`, `motif_indisponibilite`, `id_parking`, `place_parking`) VALUES ('457SIM75', 'Opel', 'Astra', 'CL3', 'berline', '4', true, null, 'P10', 'A1');
INSERT INTO `pfr`.`voiture` (`immat`, `marque`, `modele`, `id_controleur`, `categorie`, `places`, `disponibilite`, `motif_indisponibilite`, `id_parking`, `place_parking`) VALUES ('183QUJ75', 'Seat', 'Leon', 'CL3', 'berline', '4', true, null, 'P11', 'A1');
INSERT INTO `pfr`.`voiture` (`immat`, `marque`, `modele`, `id_controleur`, `categorie`, `places`, `disponibilite`, `motif_indisponibilite`, `id_parking`, `place_parking`) VALUES ('305QOK75', 'Hyundai', 'I30', 'CL3', 'berline', '4', true, null, 'P12', 'A1');
INSERT INTO `pfr`.`voiture` (`immat`, `marque`, `modele`, `id_controleur`, `categorie`, `places`, `disponibilite`, `motif_indisponibilite`, `id_parking`, `place_parking`) VALUES ('385FPO75', 'Peugeot', '308', 'CL3', 'berline', '4', true, null, 'P13', 'A1');
INSERT INTO `pfr`.`voiture` (`immat`, `marque`, `modele`, `id_controleur`, `categorie`, `places`, `disponibilite`, `motif_indisponibilite`, `id_parking`, `place_parking`) VALUES ('349PLS75', 'Mini', 'Clubman', 'CL3', 'berline', '4', true, null, 'P21', 'A2');
INSERT INTO `pfr`.`voiture` (`immat`, `marque`, `modele`, `id_controleur`, `categorie`, `places`, `disponibilite`, `motif_indisponibilite`, `id_parking`, `place_parking`) VALUES ('440DSJ75', 'Volvo', 'V40', 'CL3', 'berline', '4', true, null, 'P21', 'A3');
INSERT INTO `pfr`.`voiture` (`immat`, `marque`, `modele`, `id_controleur`, `categorie`, `places`, `disponibilite`, `motif_indisponibilite`, `id_parking`, `place_parking`) VALUES ('132SOK75', 'Alfa Romeo', 'Giulietta', 'CL3', 'berline', '4', true, null, 'P22', 'A2');
INSERT INTO `pfr`.`voiture` (`immat`, `marque`, `modele`, `id_controleur`, `categorie`, `places`, `disponibilite`, `motif_indisponibilite`, `id_parking`, `place_parking`) VALUES ('388AEO75', 'Subaru', 'Impreza', 'CL3', 'berline', '4', true, null, 'P22', 'A3');

/* ========== INSERTION DANS LA TABLE INTERVENTION ========== */
INSERT INTO `pfr`.`intervention` (`id`, `immat`, `id_controleur`, `type_intervention`, `date`) VALUES ('I1', '474SRC75', 'CL1', 'regonflage des pneus', '2018-03-22');
INSERT INTO `pfr`.`intervention` (`id`, `immat`, `id_controleur`, `type_intervention`, `date`) VALUES ('I2', '474SRC75', 'CL1', 'plein d''essence', '2018-03-22');
INSERT INTO `pfr`.`intervention` (`id`, `immat`, `id_controleur`, `type_intervention`, `date`) VALUES ('I3', '474SRC75', 'CL1', 'nettoyage intérieur', '2018-03-22');
